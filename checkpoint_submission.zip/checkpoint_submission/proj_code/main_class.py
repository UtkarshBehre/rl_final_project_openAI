# this class should have all the main functionalities and should be able to do everything by calling other classes and functions
# sort of an orchestrator
class Trainer_Tester:  # think of better name???
	def __init__(self, agent, envs):
		self.agent = agent
		self.envs = envs

		# TODO add other init parameters

	def train_agents(self):
		# TODO

	def test_agents(self):
		# TODO